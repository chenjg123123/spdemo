create definer = root@localhost trigger md5_userpwd
    before insert
    on user
    for each row
BEGIN
   SET NEW.password = MD5(NEW.password);
END;

